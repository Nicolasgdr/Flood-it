#include "Position.hpp"

Position::Position()
{

}
