#ifndef COLOR_H
#define COLOR_H
/**
     * @brief The Color enum means the different colors of the square
     */
enum Color{RED=0, BLUE=1, GREEN=2, PURPLE=3, BLACK=4, PINK=5};


#endif // COLOR_H
